import argparse
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.document_loaders import TextLoader, PyMuPDFLoader, PDFPlumberLoader
from langchain_community.vectorstores.utils import DistanceStrategy
import torch
from langchain_text_splitters import MarkdownTextSplitter
from langchain_text_splitters import MarkdownHeaderTextSplitter

embedding_model_dir = "/root/autodl-tmp/models/"


def main(args):
    # Load txt

    if '.md' in args.file_path_cn:
        file_type = 'md'
        with open(args.file_path, 'r', encoding='utf-8') as file:
            markdown_content = file.read()

        headers_to_split_on = [
            ("#", "Header 1"),
            ("##", "Header 2"),
            # ("###", "Header 3"),
        ]

        # MD splits
        markdown_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=headers_to_split_on,
            # strip_headers=False
        )
        doc = markdown_splitter.split_text(markdown_content)
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=args.cs, chunk_overlap=args.co,
            separators=[
                "\n\n",
                "\n",
                " ",
                ".",
                "。",
            ],
        )

    elif '.pdf' in args.file_path:
        file_type = 'pdf'
        loader = PyMuPDFLoader(args.file_path)
        doc = loader.load()
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=args.cs, chunk_overlap=args.co,
            separators=[
                "\n\n",
                ".",  # English period
                "。",  # Chinese period

            ],
        )

    elif '.txt' in args.file_path:
        file_type = 'txt'
        loader = TextLoader(args.file_path, encoding='utf-8')
        doc = loader.load()
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=args.cs, chunk_overlap=args.co,
            separators=[
                "\n\n",
                "\n",
                ".",  # English period
                "。",  # Chinese period

            ],
        )

    docs = text_splitter.split_documents(doc)

    model_kwargs = {'device': args.device}
    encode_kwargs = {'normalize_embeddings': True}

    embedding_model_path = embedding_model_dir + args.embedding_model

    embeddings = HuggingFaceEmbeddings(
        model_name=embedding_model_path,
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )
    if args.distpo == 'ed':
        distance_strategy = DistanceStrategy.EUCLIDEAN_DISTANCE
    elif args.distpo == 'mip':
        distance_strategy = DistanceStrategy.MAX_INNER_PRODUCT
    elif args.distpo == 'cos':
        distance_strategy = DistanceStrategy.COSINE
    elif args.distpo == 'dp':
        distance_strategy = DistanceStrategy.DOT_PRODUCT
    else:
        raise ValueError("Invalid distance strategy")

    db = FAISS.from_documents(
        documents=docs,
        embedding=embeddings,
        distance_strategy=distance_strategy
    )

    faiss_index_path = f"./db/faiss_index_cs{args.cs}_co{args.co}_distpo_{args.distpo}_{file_type}_{args.embedding_model}"
    db.save_local(faiss_index_path)  # Save the index

    print("索引保存成功:", faiss_index_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process some integers.')

    default_device = "cuda" if torch.cuda.is_available() else "cpu"

    # embedding_model = "/root/autodl-tmp/embedding_model/bge-m3"
    # embedding_model = '/root/rag-judge/algorithm/embedding_model/bge-m3'

    # embedding_model = "/root/autodl-tmp/embedding_model/bce-embedding-base_v1"

    embedding_model = "distiluse-base-multilingual-cased-v2"
    # embedding_model = 'D:\\0_ZX\\algorithm\\embedding_model\\bge-m3'

    file_path = "../zsproj/fin.txt"


    parser.add_argument("--device", type=str, default=default_device, help="Device to use for computation")

    parser.add_argument("--embedding_model", type=str, default=embedding_model,
                        help="Path to the embedding model")

    parser.add_argument("--file_path", type=str, default=file_path,
                        help="Path of the txt file which will be embedded.")

    parser.add_argument('--cs', type=int, default=150, help='The chunk size for text splitting')
    parser.add_argument('--co', type=int, default=50, help='The chunk overlap for text splitting')

    parser.add_argument('--distpo', type=str, default='cos', help='The DistanceStrategy')

    args = parser.parse_args()
    main(args)
