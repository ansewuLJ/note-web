from modelscope import snapshot_download
import os
import shutil

# 下载模型
cache_dir = "/root/autodl-tmp/models"
# cache_dir = "/root/autodl-tmp/llm"

# model_name = 'maidalun/bce-reranker-base_v1'

# model_name = 'maidalun/bce-embedding-base_v1'

# model_name = 'Xorbits/bge-m3'

model_name = 'quietnight/bge-reranker-large'

# model_name = 'qwen/Qwen1.5-14B-Chat'
# model_name = 'AI-ModelScope/bge-reranker-v2-m3'

# model_name = 'AI-ModelScope/bge-reranker-v2-gemma'

model_name_postfix = model_name.split('/')[1]

# 下载模型快照
model_dir = snapshot_download(model_name, cache_dir=cache_dir)

# 确保目标目录存在
# target_dir = os.path.join(cache_dir, "bge-m3")
target_dir = os.path.join(cache_dir, model_name_postfix)

if not os.path.exists(target_dir):
    os.makedirs(target_dir)

# 移动下载的文件到目标目录
for item in os.listdir(model_dir):
    s = os.path.join(model_dir, item)
    d = os.path.join(target_dir, item)
    if os.path.isdir(s):
        shutil.move(s, d)
    else:
        shutil.move(s, d)

# 移除原始下载目录
shutil.rmtree(os.path.dirname(model_dir))

print(f"模型已下载并移动到 {target_dir}")
