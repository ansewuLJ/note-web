from sentence_transformers import SentenceTransformer
model1 = SentenceTransformer('sentence-transformers/distiluse-base-multilingual-cased-v2')
print('下载完成')
model2 = SentenceTransformer('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')
print('下载完成')