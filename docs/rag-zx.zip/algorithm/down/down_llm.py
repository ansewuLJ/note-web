from modelscope.hub.file_download import model_file_download
# model_dir = model_file_download(model_id='qwen/Qwen1.5-14B-Chat-GGUF',file_path='qwen1_5-14b-chat-q5_k_m.gguf',revision='master',cache_dir='/root/autodl-tmp/gguf')

model_dir = model_file_download(model_id='qwen/Qwen1.5-14B-Chat-GGUF', file_path='qwen1_5-14b-chat-q8_0.gguf',
                                revision='master', cache_dir='/root/autodl-tmp/gguf')
