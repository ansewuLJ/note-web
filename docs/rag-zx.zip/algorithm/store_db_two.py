import argparse
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.document_loaders import TextLoader, PyMuPDFLoader, PDFPlumberLoader
from langchain_community.vectorstores.utils import DistanceStrategy
import torch
from langchain_text_splitters import MarkdownHeaderTextSplitter

embedding_model_dir = "/root/autodl-tmp/models/"


def main(args):

    if '.md' in args.file_path_cn:
        file_type = 'md'
        with open(args.file_path_cn, 'r', encoding='utf-8') as file:
            md_content_cn = file.read()

        with open(args.file_path_en, 'r', encoding='utf-8') as file:
            md_content_en = file.read()

        headers_to_split_on = [
            ("#", "Header 1"),
            ("##", "Header 2"),
            # ("###", "Header 3"),
        ]

        # MD splits
        markdown_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=headers_to_split_on,
            # strip_headers=False
        )
        doc_cn = markdown_splitter.split_text(md_content_cn)
        doc_en = markdown_splitter.split_text(md_content_en)

        text_splitter_cn = RecursiveCharacterTextSplitter(
            chunk_size=args.cs_cn, chunk_overlap=args.co_cn,
            separators=[
                "\n\n",
                "\n",
                " ",
                ".",
                "。",
            ],
        )
        text_splitter_en = RecursiveCharacterTextSplitter(
            chunk_size=args.cs_en, chunk_overlap=args.co_en,
            separators=[
                "\n\n",
                "\n",
                " ",
                ".",
                "。",
            ],
        )

    elif '.pdf' in args.file_path_cn:
        file_type = 'pdf'
        loader_cn = PyMuPDFLoader(args.file_path_cn)
        doc_cn = loader_cn.load()

        loader_en = PyMuPDFLoader(args.file_path_en)
        doc_en = loader_en.load()

        text_splitter_cn = RecursiveCharacterTextSplitter(
            chunk_size=args.cs_cn, chunk_overlap=args.co_cn,
            separators=[
                "\n\n",
                "\n",
                " ",
                ".",
                "。",
            ],
        )

        separators = ["\n\n", "\n", ".", "。"]

        text_splitter_en = RecursiveCharacterTextSplitter(
            chunk_size=args.cs_en, chunk_overlap=args.co_en,
            separators=[
                "\n\n",
                "\n",
                " ",
                ".",
                "。",
            ],
        )


    elif '.txt' in args.file_path_cn:
        file_type = 'txt'
        loader_cn = TextLoader(args.file_path_cn, encoding='utf-8')
        doc_cn = loader_cn.load()
        loader_en = TextLoader(args.file_path_en, encoding='utf-8')
        doc_en = loader_en.load()

        text_splitter_cn = RecursiveCharacterTextSplitter(
            chunk_size=args.cs_cn, chunk_overlap=args.co_cn,
            separators=[
                "\n\n",
                "\n",
                ".",
                "。",
            ],

            # separators=[
            #     "\n\n",
            #     "\n",
            #     " ",
            #     ".",
            #     ",",
            #     "\u200b",  # Zero-width space
            #     "\uff0c",  # Fullwidth comma
            #     "\u3001",  # Ideographic comma
            #     "\uff0e",  # Fullwidth full stop
            #     "\u3002",  # Ideographic full stop
            #     "",
            # ],
            
            
            
        )
        text_splitter_en = RecursiveCharacterTextSplitter(
            chunk_size=args.cs_en, chunk_overlap=args.co_en,
            separators=[
                "\n\n",
                "\n",
                ".",
                "。",
            ],
            # separators=[
            #     "\n\n",
            #     "\n",
            #     " ",
            #     ".",
            #     ",",
            #     "\u200b",  # Zero-width space
            #     "\uff0c",  # Fullwidth comma
            #     "\u3001",  # Ideographic comma
            #     "\uff0e",  # Fullwidth full stop
            #     "\u3002",  # Ideographic full stop
            #     "",
            # ],
            
        )

    docs_cn = text_splitter_cn.split_documents(doc_cn)
    docs_en = text_splitter_en.split_documents(doc_en)

    model_kwargs = {'device': args.device}
    encode_kwargs = {'normalize_embeddings': True}

    embedding_model_path = embedding_model_dir + args.embedding_model

    embeddings = HuggingFaceEmbeddings(
        model_name=embedding_model_path,
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )
    if args.distpo == 'ed':
        distance_strategy = DistanceStrategy.EUCLIDEAN_DISTANCE
    elif args.distpo == 'mip':
        distance_strategy = DistanceStrategy.MAX_INNER_PRODUCT
    elif args.distpo == 'cos':
        distance_strategy = DistanceStrategy.COSINE
    elif args.distpo == 'dp':
        distance_strategy = DistanceStrategy.DOT_PRODUCT
    else:
        raise ValueError("Invalid distance strategy")

    db_cn = FAISS.from_documents(
        documents=docs_cn,
        embedding=embeddings,
        distance_strategy=distance_strategy
    )

    db_en = FAISS.from_documents(
        documents=docs_en,
        embedding=embeddings,
        distance_strategy=distance_strategy
    )

    faiss_index_path_cn = f"./db/faiss_index_cscn{args.cs_cn}_cocn{args.co_cn}_distpo_{args.distpo}_{file_type}_{args.embedding_model}"

    faiss_index_path_en = f"./db/faiss_index_csen{args.cs_en}_coen{args.co_en}_distpo_{args.distpo}_{file_type}_{args.embedding_model}"

    db_cn.save_local(faiss_index_path_cn)  # Save the index
    db_en.save_local(faiss_index_path_en)  # Save the index

    print("索引保存成功:", faiss_index_path_cn)
    print("索引保存成功:", faiss_index_path_en)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process some integers.')

    default_device = "cuda" if torch.cuda.is_available() else "cpu"

    embedding_model = "distiluse-base-multilingual-cased-v2"

    parser.add_argument("--device", type=str, default=default_device, help="Device to use for computation")

    parser.add_argument("--embedding_model", type=str, default=embedding_model,
                        help="Path to the embedding model")

    parser.add_argument("--file_path_cn", type=str, help="Path of the chinese file which will be embedded.")

    parser.add_argument("--file_path_en", type=str, help="Path of the english file which will be embedded.")

    parser.add_argument('--cs_cn', type=int, default=300, help='The chunk size for text splitting')
    parser.add_argument('--co_cn', type=int, default=50, help='The chunk overlap for text splitting')

    parser.add_argument('--cs_en', type=int, default=700, help='The chunk size for text splitting')
    parser.add_argument('--co_en', type=int, default=150, help='The chunk overlap for text splitting')

    parser.add_argument('--distpo', type=str, default='cos', help='The DistanceStrategy')

    args = parser.parse_args()
    main(args)
