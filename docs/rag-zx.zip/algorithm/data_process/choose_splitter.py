from langchain_text_splitters import MarkdownHeaderTextSplitter
from langchain_text_splitters.character import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader, PyMuPDFLoader, PDFPlumberLoader


md_path_cn = "./data/fin_cn.md"
md_path_en = "./data/fin_en.md"

txt_path_cn = "./data/fin_cn.txt"
txt_path_en = "./data/fin_en.txt"

with open(md_path_cn, 'r', encoding='utf-8') as file:
    md_content_cn = file.read()

with open(md_path_en, 'r', encoding='utf-8') as file:
    md_content_en = file.read()

cs_cn = 300
co_cn = 50

cs_en = 500
co_en = 100



headers_to_split_on = [
    ("#", "Header 1"),
    ("##", "Header 2"),
    # ("###", "Header 3"),
]

# MD splits
markdown_splitter = MarkdownHeaderTextSplitter(
    headers_to_split_on=headers_to_split_on,
    # strip_headers=False
)
md_header_splits_cn = markdown_splitter.split_text(md_content_cn)
md_header_splits_en = markdown_splitter.split_text(md_content_en)

# print('head:\n', md_header_splits)
text_splitter_cn = RecursiveCharacterTextSplitter(
    chunk_size=cs_cn, chunk_overlap=co_cn,
    separators=[
        "\n\n",
        "\n",
        # " ",
        ".",
        "。",
    ],

    # separators=[
    #     "\n\n",
    #     "\n",
    #     " ",
    #     ".",
    #     ",",
    #     "\u200b",  # Zero-width space
    #     "\uff0c",  # Fullwidth comma
    #     "\u3001",  # Ideographic comma
    #     "\uff0e",  # Fullwidth full stop
    #     "\u3002",  # Ideographic full stop
    #     "",
    # ],


)

text_splitter_en = RecursiveCharacterTextSplitter(
    chunk_size=cs_en, chunk_overlap=co_en,
    separators=[
        "\n\n",
        "\n",
        # " ",
        ".",
        "。",
    ],

    # separators=[
    #     "\n\n",
    #     "\n",
    #     " ",
    #     ".",
    #     ",",
    #     "\u200b",  # Zero-width space
    #     "\uff0c",  # Fullwidth comma
    #     "\u3001",  # Ideographic comma
    #     "\uff0e",  # Fullwidth full stop
    #     "\u3002",  # Ideographic full stop
    #     "",
    # ],



)

# Split
docs_cn = text_splitter_cn.split_documents(md_header_splits_cn)
docs_en = text_splitter_en.split_documents(md_header_splits_en)
# print('\nsplit_docs[1]:\n', docs_cn[1].page_content)
docs_lens_cn = [len(doc_i.page_content) for doc_i in docs_cn]
docs_lens_en = [len(doc_i.page_content) for doc_i in docs_en]
# print(docs_lens)
print('md cn chunk num:', len(docs_cn))

print('md cn avg chunk size:', sum(docs_lens_cn)/len(docs_lens_cn))
print('md cn max chunk size: ', max(docs_lens_cn))

print('md en chunk num:', len(docs_en))

print('md en avg chunk size:', sum(docs_lens_en)/len(docs_lens_en))
print('md en max chunk size: ', max(docs_lens_en))
print('md max cn idx:', docs_lens_cn.index(max(docs_lens_cn)))
print('md max en idx:', docs_lens_en.index(max(docs_lens_en)))


print('\n\n')
loader_cn = TextLoader(txt_path_cn, encoding='utf-8')
doc_cn = loader_cn.load()
loader_en = TextLoader(txt_path_en, encoding='utf-8')
doc_en = loader_en.load()

text_splitter_cn = RecursiveCharacterTextSplitter(
    chunk_size=cs_cn, chunk_overlap=co_cn,
    separators=[
        "\n\n",
        "\n",
        ".",
        "。",
    ],
)

text_splitter_en = RecursiveCharacterTextSplitter(
    chunk_size=cs_en, chunk_overlap=co_en,
    separators=[
        "\n\n",
        "\n",
        ".",
        "。",
    ],
)

docs_cn = text_splitter_cn.split_documents(doc_cn)
docs_en = text_splitter_en.split_documents(doc_en)


docs_lens_cn = [len(doc_i.page_content) for doc_i in docs_cn]
docs_lens_en = [len(doc_i.page_content) for doc_i in docs_en]
# print(docs_lens)
print('txt cn chunk num:', len(docs_cn))

print('txt cn avg chunk size:', sum(docs_lens_cn)/len(docs_lens_cn))
print('txt cn max chunk size: ', max(docs_lens_cn))

print('txt en chunk num:', len(docs_en))

print('txt en avg chunk size:', sum(docs_lens_en)/len(docs_lens_en))
print('txt en max chunk size: ', max(docs_lens_en))

print('txt max cn idx:', docs_lens_cn.index(max(docs_lens_cn)))
print('txt max en idx:', docs_lens_en.index(max(docs_lens_en)))




