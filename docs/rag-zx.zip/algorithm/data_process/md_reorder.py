import re

def process_markdown(input_text):
    # 按段落分隔文本
    paragraphs = input_text.split('\n\n')

    processed_paragraphs = []
    current_heading = None  # 记录当前处理的标题级别
    current_paragraph = []  # 当前处理的段落

    for paragraph in paragraphs:
        # 判断当前段落是否为标题
        if paragraph.startswith('#'):
            # 如果存在前一个段落，将其添加到处理后的段落列表中
            if current_paragraph:
                processed_paragraphs.append('\n'.join(current_paragraph))
                current_paragraph = []
            # 记录当前标题级别，并初始化新的段落
            current_heading = paragraph.split(' ')[0]
            current_paragraph.append(paragraph.strip())
        else:
            # 处理段落中的连字符
            paragraph = re.sub(r'(\w)-\n(\w)', r'\1\2', paragraph)

            # 处理英文段落中的换行符，将它们替换为单个空格
            paragraph = re.sub(r'([a-zA-Z])\n([a-zA-Z])', r'\1 \2', paragraph)
            # 处理中文段落中的换行符，将它们直接删除
            paragraph = re.sub(r'([^\x00-\x7F])\n([^\x00-\x7F])', r'\1\2', paragraph)

            # 替换段落中的多个空格为单个空格
            paragraph = re.sub(r'\s+', ' ', paragraph)

            # 将段落按句子分隔并添加到当前段落
            sentences = re.split(r'(?<=[。！？])', paragraph)
            for sentence in sentences:
                if sentence.strip():
                    current_paragraph.append(sentence.strip())

    # 添加最后一个段落到处理后的段落列表中
    if current_paragraph:
        processed_paragraphs.append('\n'.join(current_paragraph))

    # 重新组合处理后的段落
    processed_text = '\n\n'.join(processed_paragraphs)

    return processed_text

file_type_list = ['cn', 'en']
for file_type in file_type_list:

    input_file_path = f'./cleaned_md/fin_{file_type}.md'
    output_file_path = f'./final/fin_{file_type}.md'


    with open(input_file_path, 'r', encoding='utf-8') as file1:
        input_text = file1.read()


    processed_text = process_markdown(input_text)
    # print(processed_text)
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        output_file.write(processed_text)

    print('转换完成\n{} ---> {}'.format(input_file_path, output_file_path))
# print('\n\n')
# print(repr(processed_text))
