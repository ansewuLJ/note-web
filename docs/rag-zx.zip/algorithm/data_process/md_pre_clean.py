import re
import time

def process_and_clean_markdown(file_path, output_path):
    def clean_markdown(lines):
        cleaned_lines = []
        for line in lines:
            # 如果行中包含竖线 | 或者显示图片的Markdown语句，则删除该行
            if ' | ' in line or re.search(r'!\[.*\]\(.*\)', line):
                continue
            # 删除出现连续四个或更多“1”、“七”、“-”、“⋅”的行
            if re.search(r'一{3,}|七{3,}|-{3,}|⋅{3,}', line):
                continue
            # 去除连续的 ---- (四个或更多连字符)
            line = re.sub(r'-{4,}', '', line)
            cleaned_lines.append(line)
        return cleaned_lines

    def remove_inline_formulas(content):
        # 删除所有包含$$$$的内容
        return re.sub(r'\$\$.*?\$\$', '', content, flags=re.DOTALL)

    def process_space(lines):
        # 去除中文之间的多余空格
        processed_lines = []
        for line in lines:
            if any('\u4e00' <= char <= '\u9fff' for char in line):
                line = re.sub(r'([\u4e00-\u9fff])\s+([\u4e00-\u9fff])', r'\1\2', line)
            processed_lines.append(line)

        # 将超过一行的空白行变成一行空白行
        cleaned_lines = []
        empty_line = False
        for line in processed_lines:
            if line.strip() == '':
                if not empty_line:
                    cleaned_lines.append(line)
                    empty_line = True
            else:
                cleaned_lines.append(line)
                empty_line = False
        return cleaned_lines

    # 读取文件
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # 执行清理操作
    cleaned_lines = clean_markdown(lines)
    cleaned_content = ''.join(cleaned_lines)
    cleaned_content = remove_inline_formulas(cleaned_content)
    final_lines = process_space(cleaned_content.splitlines(True))

    # 写入清理后的文件
    with open(output_path, 'w', encoding='utf-8') as file:
        file.writelines(final_lines)

file_type_list = ['cn', 'en']

for file_type in file_type_list:
    input_file = f'./two_merged_md/fin_{file_type}.md'
    output_file = f'./cleaned_md/fin_{file_type}.md'

    process_and_clean_markdown(input_file, output_file)
print('md文件数据清洗完成')