import os
from PyPDF2 import PdfWriter, PdfReader

# 指定文件夹路径
# folder_path = '../refs/cn'
# # 合并后的 PDF 文件保存路径
# merged_pdf_path = '../refs/all/all_cn.pdf'


folder_path = '../refs/ZTE'
# 合并后的 PDF 文件保存路径
merged_pdf_path = '../refs/all/all_ZTE.pdf'




# cn: 4/2 jx 1/2 en 2/2 ZTE 3/1
rm_start_page_num = 3
rm_end_page_num = 1

# merged_pdf_path = 'D:\0_ZX\提交文件\rag-last\zsproj\cn_pdfs\cn'

# 创建保存合并后的文件的文件夹
merged_pdf_folder = os.path.dirname(merged_pdf_path)
if not os.path.exists(merged_pdf_folder):
    os.makedirs(merged_pdf_folder)

# 初始化合并后的 PDF 文件
merged_pdf = PdfWriter()

# 遍历文件夹中的所有 PDF 文件
for filename in os.listdir(folder_path):
    if filename.endswith('.pdf'):
        pdf_path = folder_path + '/' + filename
        # pdf_path = os.path.join(folder_path, filename)
        abs_pdf_path = os.path.abspath(pdf_path)  # 获取绝对路径
        print(f"Absolute path: {abs_pdf_path}")

        if os.path.exists(abs_pdf_path):
            print("File exists.")
            with open(abs_pdf_path, "rb") as file:
                pdf_reader = PdfReader(file)
        else:
            print("File does not exist.")
        # 读取 PDF 文件
        pdf_reader = PdfReader(open(pdf_path, "rb"))
        num_pages = len(pdf_reader.pages)

        # 提取页面并添加到合并后的 PDF 文件中
        for i in range(rm_start_page_num, num_pages-rm_end_page_num):
            merged_pdf.add_page(pdf_reader.pages[i])

# 保存合并后的 PDF 文件
with open(merged_pdf_path, "wb") as mergedStream:
    merged_pdf.write(mergedStream)

print(f"合并后的 PDF 文件已保存至: {merged_pdf_path}")
