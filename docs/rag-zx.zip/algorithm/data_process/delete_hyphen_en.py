import re

def process_md_file(input_file, output_file):
    # 读取Markdown文件内容
    with open(input_file, 'r', encoding='utf-8') as f:
        md_content = f.read()

    # 使用正则表达式替换不规范的连接符和空格
    md_content_processed = re.sub(r'\b([a-zA-Z]+)\s*‐\s*([a-zA-Z]+)\b', r'\1\2', md_content)

    # 写入处理后的内容到输出文件
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(md_content_processed)

input_file = './final/fin_en.md'
output_file = './final/fin_en.md'
process_md_file(input_file, output_file)


print('替换完成：in >> {}, out >> {}'.format(input_file, output_file))
