import csv
import re
import matplotlib.pyplot as plt

csv_path = './test_A.csv'
chinese_question_lengths = []  # 存储所有中文问题的长度
english_question_lengths = []  # 存储所有英文问题的长度


# 判断文本是否包含中文字符的函数
def contains_chinese(text):
    return bool(re.search('[\u4e00-\u9fff]', text))


# 打开 CSV 文件
with open(csv_path, 'r', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)

    # 遍历每一行数据
    for row in reader:
        question = row['question']

        # 计算问题的字符长度
        length = len(question.strip())  # 使用strip()去除首尾空格并计算长度

        # 判断问题是否包含中文
        if contains_chinese(question):
            chinese_question_lengths.append(length)
        else:
            english_question_lengths.append(length)

# 统计长度分布情况
interval_size = 50  # 按字符长度分段，每段长度为50个字符

# 中文问题长度分布
chinese_length_counts = {}
for length in chinese_question_lengths:
    interval_label = f"{(length // interval_size) * interval_size}-{(length // interval_size + 1) * interval_size}"

    if interval_label in chinese_length_counts:
        chinese_length_counts[interval_label] += 1
    else:
        chinese_length_counts[interval_label] = 1

# 英文问题长度分布
english_length_counts = {}
for length in english_question_lengths:
    interval_label = f"{(length // interval_size) * interval_size}-{(length // interval_size + 1) * interval_size}"

    if interval_label in english_length_counts:
        english_length_counts[interval_label] += 1
    else:
        english_length_counts[interval_label] = 1

# 将统计结果转换为柱状图数据
labels = sorted(set(chinese_length_counts.keys()).union(set(english_length_counts.keys())), key=lambda x: int(x.split('-')[0]))
index = range(len(labels))

chinese_values = [chinese_length_counts[label] if label in chinese_length_counts else 0 for label in labels]
english_values = [english_length_counts[label] if label in english_length_counts else 0 for label in labels]

# 绘制柱状图
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10), sharex=True)

bar_width = 0.8  # 减小柱形的宽度

ax1.bar(index, chinese_values, bar_width, label='Chinese Questions', color='red')
ax1.set_ylabel('Number of Questions', fontsize='x-large')  # 调整y轴标签字体大小为较大
ax1.set_title('Distribution of Question Character Lengths', fontsize='x-large')  # 调整标题字体大小为较大
ax1.legend(fontsize='large')  # 调整图例字体大小为大号

ax2.bar(index, english_values, bar_width, label='English Questions', color='blue', alpha=0.7)
ax2.set_xlabel('Character Length Intervals (50 characters per interval)', fontsize='x-large')  # 调整x轴标签字体大小为较大
ax2.set_ylabel('Number of Questions', fontsize='x-large')  # 调整y轴标签字体大小为较大
ax2.legend(fontsize='large')  # 调整图例字体大小为大号

plt.xticks(index, labels, rotation=45, fontsize='large')  # 调整刻度标签字体大小为大号
plt.yticks(fontsize='large')  # 调整y轴刻度标签字体大小为大号
plt.tight_layout()
# 保存图像
plt.savefig('./q_len_dist.png', dpi=300)  # 增加dpi以提高图像质量
plt.show()
