import re

def convert_md_to_txt(md_file, txt_file):
    # 读取Markdown文件
    with open(md_file, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # 处理每一行
    processed_lines = []
    for line in lines:
        # 去除所有级别的Markdown标题标记（#、##、### 等）
        processed_line = re.sub(r'^\s*#+\s*', '', line)
        # 如果处理后的行不是空行，则添加到结果中
        if processed_line.strip():
            processed_lines.append(processed_line)

    # 将处理后的内容写入文本文件
    with open(txt_file, 'w', encoding='utf-8') as file:
        file.writelines(processed_lines)
# 示例使用


file_type_list = ['cn', 'en']
for file_type in file_type_list:

    input_file = f'./final/fin_{file_type}.md'
    output_file = f'./final/fin_{file_type}.txt'

    convert_md_to_txt(input_file, output_file)

print('md转txt完成！')
