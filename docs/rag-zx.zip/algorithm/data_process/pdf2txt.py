import pytesseract
from PIL import Image
import os
import fitz
'''ref to https://blog.csdn.net/RenGJ010617/article/details/137122528 
https://blog.csdn.net/justlpf/article/details/127728286
'''
# # 设置TESSDATA_PREFIX环境变量，这是你自己的训练库所在位置，训练库去官网下载
# os.environ['TESSDATA_PREFIX'] = r'D:\0_ZX\Tesseract-OCR\tessdata'
# # 设置Tesseract OCR引擎的路径，下载的引擎路径
# pytesseract.pytesseract.tesseract_cmd = r'D:\0_ZX\Tesseract-OCR\tesseract.exe'

# 设置TESSDATA_PREFIX环境变量，指向您的训练库所在位置
os.environ['TESSDATA_PREFIX'] = '/usr/share/tesseract-ocr/4.00/tessdata'

# 设置Tesseract OCR引擎的路径
pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'



def recognize_text_from_pdf(pdf_path, txt_path, language='chi_sim'):
    # 打开PDF文件
    pdf_document = fitz.open(pdf_path)
    all_text = ""
    # 将PDF的每一页转化为图片，再识别内容
    for pg in range(pdf_document.page_count):
        page = pdf_document[pg]
        rotate = int(0)
        # 清晰度在这改(设为1.33333333是1056x816像素;设为2是>1584x1224像素)
        zoom_x = 2
        zoom_y = 2
        mat = fitz.Matrix(zoom_x, zoom_y).prerotate(rotate)
        pix = page.get_pixmap(matrix=mat, alpha=False)

        image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

        # 使用Tesseract OCR引擎识别图片中的文本
        text = pytesseract.image_to_string(image, lang=language)

        all_text += text + "\n\n"
        # all_text += text + "\n"

    # 关闭PDF文件
    pdf_document.close()
    with open(txt_path, 'w', encoding='utf-8') as file:
        file.write(all_text)

    print(f"PDF {pdf_path} 转为txt完成！")


def delete_blank_line(txt_path):
    # Read the file content
    with open(txt_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # Remove extra spaces, blank lines, and extra spaces between words
    cleaned_lines = []
    for line in lines:
        # Split the line into words, strip each word, and then join them with a single space
        stripped_line = ' '.join(line.split())
        # Only add non-empty lines
        if stripped_line:
            cleaned_lines.append(stripped_line + '\n')

    # Write the cleaned content back to the file
    with open(txt_path, 'w', encoding='utf-8') as file:
        file.writelines(cleaned_lines)

    print(f"Blank lines removed in {txt_path}!")
    print('txt file saved to:', txt_path)


def process_all_pdfs_in_folder(folder_path, language='eng'):
    for filename in os.listdir(folder_path):
        if filename.endswith('.pdf'):
            pdf_path = os.path.join(folder_path, filename)
            txt_path = folder_path + '_txt/' + filename.split('pdf')[0] + 'txt'
            recognize_text_from_pdf(pdf_path, txt_path, language)
            delete_blank_line(txt_path)

# 设置PDF文件夹路径
# folder_path = '../zsproj/en'  # 替换为你的PDF文件夹路径
# folder_path = '../zsproj/fin_cn'  # 替换为你的PDF文件夹路径


# folder_path = 'D:\\0_ZX\\提交文件\\rag-last\\zsproj\\fin_cn'
folder_path = '/root/rag-judge/zsproj/fin_cn'



# process_all_pdfs_in_folder(folder_path, language='eng')  # 'eng' 或 'chi_sim'
process_all_pdfs_in_folder(folder_path, language='chi_sim')  # 'eng' 或 'chi_sim'