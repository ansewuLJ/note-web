def merge_two_markdown_files(file_path1, file_path2, output_file_path):
    # 打开第一个Markdown文件并读取内容
    with open(file_path1, 'r', encoding='utf-8') as file1:
        content1 = file1.read()

    # 打开第二个Markdown文件并读取内容
    with open(file_path2, 'r', encoding='utf-8') as file2:
        content2 = file2.read()

    # 合并两个文件的内容
    merged_content = content1 + '\n\n' + content2

    # 将合并后的内容写入新的Markdown文件
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        output_file.write(merged_content)

# 使用示例

cn_md_path1 = './four_ori_md/all_cn.md'
jx_md_path2 = './four_ori_md/all_jx.md'
output_cn_path = './two_merged_md/fin_cn.md'

en_md_path1 = './four_ori_md/all_en.md'
zte_md_path2 = './four_ori_md/all_ZTE.md'
output_en_path = './two_merged_md/fin_en.md'


# file_path1 = './four_ori_md/all_en.md'
# file_path2 = './four_ori_md/all_ZTE.md'
# output_file_path = './two_merged_md/fin_en.md'

#

merge_two_markdown_files(cn_md_path1, jx_md_path2, output_cn_path)
merge_two_markdown_files(en_md_path1, zte_md_path2, output_en_path)

print('Markdown文件合并完成。')
