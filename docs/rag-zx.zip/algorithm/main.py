import argparse
import pandas as pd
from collections import Counter
import sys
import torch
import gc
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.llms import Ollama
from langchain_core.output_parsers import StrOutputParser
from langchain_community.document_transformers import LongContextReorder
from langchain.retrievers import ContextualCompressionRetriever
from BCEmbedding.tools.langchain import BCERerank
from langchain.retrievers import EnsembleRetriever
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder

import warnings
warnings.filterwarnings("ignore")

embedding_model_dir = "/root/autodl-tmp/models/"

# 自定义输出解析器
class CustomOutputParser(StrOutputParser):
    def parse(self, output: str) -> str:
        if "T" in output:
            return "T"
        else:
            return "F"


def run(args):
    # 嵌入模型路径
    # model_name = args.embedding_model
    model_kwargs = {'device': args.device
                    # , 'trust_remote_code': True,
                    }
    encode_kwargs = {'normalize_embeddings': True}
    model_path1 = embedding_model_dir + args.em1

    # 初始化嵌入模型
    embeddings1 = HuggingFaceEmbeddings(
        model_name=model_path1,
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )

    if args.use_two_em:
        model_path2 = embedding_model_dir + args.em2
        embeddings2 = HuggingFaceEmbeddings(
            model_name=model_path2,
            model_kwargs=model_kwargs,
            encode_kwargs=encode_kwargs
        )

    search_kwargs = {'k': args.topk1, 'search_type': args.st}
    post_csv = args.input_file.split('_')[1][0]
    if args.use_two_em:
        if args.use_two_db:

            faiss_index_path_cn_em1 = f"./db/faiss_index_cscn{args.cs_cn}_cocn{args.co_cn}_distpo_{args.distpo}_{args.file_type}_{args.em1}"
            faiss_index_path_en_em1 = f"./db/faiss_index_csen{args.cs_en}_coen{args.co_en}_distpo_{args.distpo}_{args.file_type}_{args.em1}"
            faiss_index_path_cn_em2 = f"./db/faiss_index_cscn{args.cs_cn}_cocn{args.co_cn}_distpo_{args.distpo}_{args.file_type}_{args.em2}"
            faiss_index_path_en_em2 = f"./db/faiss_index_csen{args.cs_en}_coen{args.co_en}_distpo_{args.distpo}_{args.file_type}_{args.em2}"

            db_cn_em1 = FAISS.load_local(faiss_index_path_cn_em1, embeddings1, allow_dangerous_deserialization=True)
            db_en_em1 = FAISS.load_local(faiss_index_path_en_em1, embeddings1, allow_dangerous_deserialization=True)

            db_cn_em2 = FAISS.load_local(faiss_index_path_cn_em2, embeddings2, allow_dangerous_deserialization=True)
            db_en_em2 = FAISS.load_local(faiss_index_path_en_em2, embeddings2, allow_dangerous_deserialization=True)

            retriever_cn_em1 = db_cn_em1.as_retriever(search_kwargs=search_kwargs)
            retriever_en_em1 = db_en_em1.as_retriever(search_kwargs=search_kwargs)
            retriever_em1 = EnsembleRetriever(
                retrievers=[retriever_cn_em1, retriever_en_em1], weights=[0.5, 0.5]
            )

            retriever_cn_em2 = db_cn_em2.as_retriever(search_kwargs=search_kwargs)
            retriever_en_em2 = db_en_em2.as_retriever(search_kwargs=search_kwargs)
            retriever_em2 = EnsembleRetriever(
                retrievers=[retriever_cn_em2, retriever_en_em2], weights=[0.5, 0.5]
            )
            retriever = EnsembleRetriever(
                retrievers=[retriever_em1, retriever_em2], weights=[0.5, 0.5]
            )

            output_file = f'../data/two_em_cscn{args.cs_cn}_cocn{args.co_cn}_csen{args.cs_en}_coen{args.co_en}_topk1_{args.topk1}_st_{args.st}_' \
                          f'{args.file_type}_llm_{args.llm_name}_em1_{args.em1}_em2_{args.em2}_rerank_{args.use_rerank}_{args.rerank_model}_topk2_{args.topk2}_{post_csv}.csv'

        else:
            faiss_index_path_em1 = f'./db/faiss_index_cs{args.cs}_co{args.co}_distpo_{args.distpo}_{args.file_type}_{args.em1}'
            faiss_index_path_em2 = f'./db/faiss_index_cs{args.cs}_co{args.co}_distpo_{args.distpo}_{args.file_type}_{args.em2}'
            db_em1 = FAISS.load_local(faiss_index_path_em1, embeddings1, allow_dangerous_deserialization=True)
            db_em2 = FAISS.load_local(faiss_index_path_em2, embeddings2, allow_dangerous_deserialization=True)

            retriever_em1 = db_em1.as_retriever(search_kwargs=search_kwargs)
            retriever_em2 = db_em2.as_retriever(search_kwargs=search_kwargs)

            retriever = EnsembleRetriever(
                retrievers=[retriever_em1, retriever_em2], weights=[0.5, 0.5]
            )

            output_file = f'../data/two_em_cs{args.cs}_co{args.co}_topk1_{args.topk1}_st_{args.st}_' \
                          f'{args.file_type}_llm_{args.llm_name}_em1_{args.em1}_em2_{args.em2}_rerank_{args.use_rerank}_{args.rerank_model}_topk2_{args.topk2}_{post_csv}.csv'


    else:

        if args.use_two_db:
            faiss_index_path_cn = f"./db/faiss_index_cscn{args.cs_cn}_cocn{args.co_cn}_distpo_{args.distpo}_{args.file_type}_{args.embedding_model}"
            faiss_index_path_en = f"./db/faiss_index_csen{args.cs_en}_coen{args.co_en}_distpo_{args.distpo}_{args.file_type}_{args.embedding_model}"

            db_cn = FAISS.load_local(faiss_index_path_cn, embeddings1, allow_dangerous_deserialization=True)
            db_en = FAISS.load_local(faiss_index_path_en, embeddings1, allow_dangerous_deserialization=True)
            retriever_cn = db_cn.as_retriever(search_kwargs=search_kwargs)
            retriever_en = db_en.as_retriever(search_kwargs=search_kwargs)
            retriever = EnsembleRetriever(
                retrievers=[retriever_cn, retriever_en], weights=[0.5, 0.5]
            )

            output_file = f'../data/cscn{args.cs_cn}_cocn{args.co_cn}_csen{args.cs_en}_coen{args.co_en}_topk1_{args.topk1}_st_{args.st}_' \
                          f'{args.file_type}_llm_{args.llm_name}_em_{args.em1}_rerank_{args.use_rerank}_{args.rerank_model}_topk2_{args.topk2}_{post_csv}.csv'


        else:
            faiss_index_path = f'./db/faiss_index_cs{args.cs}_co{args.co}_distpo_{args.distpo}_{args.file_type}_{args.embedding_model}'

            db = FAISS.load_local(faiss_index_path, embeddings1, allow_dangerous_deserialization=True)
            retriever = db.as_retriever(search_kwargs=search_kwargs)

            output_file = f'../data/cs{args.cs}_co{args.co}_topk1_{args.topk1}_st_{args.st}_' \
                          f'{args.file_type}_llm_{args.llm_name}_em_{args.em1}_rerank_{args.use_rerank}_{args.rerank_model}_topk2_{args.topk2}_{post_csv}.csv'

    # 创建llm模型
    llm = Ollama(model=args.llm_name, temperature=args.temperature, num_ctx=args.num_ctx)
    output_parser = CustomOutputParser()

    prompt = ChatPromptTemplate.from_template(
        """给定以下上下文和一个陈述，请根据提供的上下文判断陈述是否正确。
        请特别注意细节和微小的差异，这些细节可能会影响判断的正确性。
        只需判断正确还是错误，如果正确就输出"T"，如果错误就输出"F"。
        如果根据上下文无法确认是正确的，则默认错误，输出"F"。
        注意过于绝对的说法一般是错误的。
        你的最终输出应该只包含"T"、"F"中的一个，不用说明理由。
        上下文: {context}
        陈述: {input}"""
    )
    
    # 生成chain ： prompt | llm
    document_chain = create_stuff_documents_chain(llm, prompt, output_parser=output_parser)

    rarank_model_path = embedding_model_dir + args.rerank_model

    if 'bce' in args.rerank_model:
        reranker_args = {'model': rarank_model_path, 'top_n': args.topk2, 'device': args.device}
        reranker = BCERerank(**reranker_args)
    elif 'bge' in args.rerank_model:
        model_kwargs = {'device': args.device,
                        # 'trust_remote_code': True
                        }
        temp_model = HuggingFaceCrossEncoder(model_name=rarank_model_path,
                                             model_kwargs=model_kwargs)
        reranker = CrossEncoderReranker(model=temp_model, top_n=args.topk2)

    compression_retriever = ContextualCompressionRetriever(
        base_compressor=reranker, base_retriever=retriever
    )

    # 读取CSV文件
    df = pd.read_csv(args.input_file)

    # 创建一个空的 DataFrame 用于存储结果
    result_df = pd.DataFrame(columns=['id', 'answer'])

    if args.use_rerank:
        final_retriever = compression_retriever
    else:
        final_retriever = retriever

    reordering = LongContextReorder()
    # 遍历每一行，进行检索和判断
    ans = Counter()
    for index, row in df.iterrows():
        question_id = row['id']
        query = row['question']

        # docs = retriever.invoke(query)
        docs = final_retriever.invoke(query)

        docs = reordering.transform_documents(docs)

        response = document_chain.invoke({"context": docs, "input": query})
        # response = document_chain.invoke({"context": docs, "input": query})

        final_answer = response
        print("已判断：", question_id, " 结果：", final_answer)
        ans[final_answer] += 1

        # 将结果添加到结果 DataFrame 中
        result_df = result_df._append({'id': question_id, 'answer': final_answer}, ignore_index=True)
        gc.collect()
        torch.cuda.empty_cache()

    result_df.to_csv(output_file, index=False)

    print("判断结果已写入:", output_file)

    # 假设在某个条件下调用终止程序
    sys.exit()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the document retrieval and judgment process")

    default_device = "cuda" if torch.cuda.is_available() else "cpu"

    # embedding_model = "/root/rag-judge/algorithm/embedding_model/bge-m3"

    rerank_model = "bce-rerank-base_v1"
    llm_name = 'qwen1_5-14b-chat-q8_0'
    # llm_name = 'qwen2:7b'

    parser.add_argument("--device", type=str, default=default_device, help="Device to use for computation")
    parser.add_argument("--rerank_model", type=str, default=rerank_model, help="rerank model name")
    parser.add_argument("--llm_name", type=str, default=llm_name, help="LLM model name")

    parser.add_argument("--file_type", type=str, default='md', help="file embedded type")

    parser.add_argument("--cs", type=int, default=300, help="cs value")
    parser.add_argument("--co", type=int, default=50, help="co value")

    parser.add_argument('--cs_cn', type=int, default=300, help='The chunk size for text splitting')
    parser.add_argument('--co_cn', type=int, default=50, help='The chunk overlap for text splitting')

    parser.add_argument('--cs_en', type=int, default=700, help='The chunk size for text splitting')
    parser.add_argument('--co_en', type=int, default=150, help='The chunk overlap for text splitting')

    parser.add_argument("--distpo", type=str, default='cos', help="distance strategy of faiss")
    parser.add_argument("--temperature", type=float, default=0.0, help="Temperature for the LLM model")
    parser.add_argument("--num_ctx", type=int, default=8192, help="Number of contexts for the LLM model")
    parser.add_argument("--topk1", type=int, default=20, help="Top k documents to retrieve")
    parser.add_argument("--topk2", type=int, default=6, help="final Top k documents to llm")
    parser.add_argument("--input_file", type=str, default='./data/test_A.csv', help="Path to the input CSV file")
    parser.add_argument("--st", type=str, default='mmr', help="'similarity/mmr , Search type for retriever")
    # parser.add_argument("--lam", type=float, default=0.5, help="Lambda multiplier for retriever")

    parser.add_argument('--use_rerank', action='store_false', default=True, help='use reranker')

    parser.add_argument('--use_two_db', action='store_true', default=False,
                        help='whether to use two databases: cn and en')

    parser.add_argument('--use_two_em', action='store_true', default=False,
                        help='whether to use two embedding models to enhance the search results')
    parser.add_argument("--em1", type=str, default='distiluse-base-multilingual-cased-v2',
                        help="embedding model 1 name")
    parser.add_argument("--em2", type=str, default='paraphrase-multilingual-MiniLM-L12-v2',
                        help="embedding model 2 name")

    args = parser.parse_args()
    run(args)
