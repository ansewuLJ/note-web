from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.llms import Ollama
from langchain_core.output_parsers import StrOutputParser
from langchain_community.document_transformers import LongContextReorder
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder
from langchain.retrievers import EnsembleRetriever

import streamlit as st
from langchain.retrievers import ContextualCompressionRetriever
from BCEmbedding.tools.langchain import BCERerank

import warnings
warnings.filterwarnings("ignore")

embedding_model_dir = "/root/autodl-tmp/models/"

# 自定义输出解析器
class CustomOutputParser(StrOutputParser):
    def parse(self, output: str) -> str:
        if "T" in output:
            return "T"
        else:
            return "F"


def load_index_model(file_type, use_two_em, em1, em2, use_two_db, cs_cn, co_cn, cs_en, co_en, cs, co, k1, search_type,
                     lambda_mult,
                     dist_po, model_kwargs, encode_kwargs):
    model_path1 = embedding_model_dir + em1
    # 初始化嵌入模型
    embeddings1 = HuggingFaceEmbeddings(
        model_name=model_path1,
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )
    if use_two_em:
        model_path2 = embedding_model_dir + em2
        embeddings2 = HuggingFaceEmbeddings(
            model_name=model_path2,
            model_kwargs=model_kwargs,
            encode_kwargs=encode_kwargs
        )

    search_kwargs = {'k': k1, 'search_type': search_type, 'lambda_mult': lambda_mult}

    if use_two_em:
        if use_two_db:

            faiss_index_path_cn_em1 = f"./db/faiss_index_cscn{cs_cn}_cocn{co_cn}_distpo_{dist_po}_{file_type}_{em1}"
            faiss_index_path_en_em1 = f"./db/faiss_index_csen{cs_en}_coen{co_en}_distpo_{dist_po}_{file_type}_{em1}"
            faiss_index_path_cn_em2 = f"./db/faiss_index_cscn{cs_cn}_cocn{co_cn}_distpo_{dist_po}_{file_type}_{em2}"
            faiss_index_path_en_em2 = f"./db/faiss_index_csen{cs_en}_coen{co_en}_distpo_{dist_po}_{file_type}_{em2}"

            db_cn_em1 = FAISS.load_local(faiss_index_path_cn_em1, embeddings1, allow_dangerous_deserialization=True)
            db_en_em1 = FAISS.load_local(faiss_index_path_en_em1, embeddings1, allow_dangerous_deserialization=True)

            db_cn_em2 = FAISS.load_local(faiss_index_path_cn_em2, embeddings2, allow_dangerous_deserialization=True)
            db_en_em2 = FAISS.load_local(faiss_index_path_en_em2, embeddings2, allow_dangerous_deserialization=True)

            retriever_cn_em1 = db_cn_em1.as_retriever(search_kwargs=search_kwargs)
            retriever_en_em1 = db_en_em1.as_retriever(search_kwargs=search_kwargs)
            retriever_em1 = EnsembleRetriever(
                retrievers=[retriever_cn_em1, retriever_en_em1], weights=[0.5, 0.5]
            )

            retriever_cn_em2 = db_cn_em2.as_retriever(search_kwargs=search_kwargs)
            retriever_en_em2 = db_en_em2.as_retriever(search_kwargs=search_kwargs)
            retriever_em2 = EnsembleRetriever(
                retrievers=[retriever_cn_em2, retriever_en_em2], weights=[0.5, 0.5]
            )
            retriever = EnsembleRetriever(
                retrievers=[retriever_em1, retriever_em2], weights=[0.5, 0.5]
            )


        else:
            faiss_index_path_em1 = f'./db/faiss_index_cs{cs}_co{co}_distpo_{dist_po}_{file_type}_{em1}'
            faiss_index_path_em2 = f'./db/faiss_index_cs{cs}_co{co}_distpo_{dist_po}_{file_type}_{em2}'
            db_em1 = FAISS.load_local(faiss_index_path_em1, embeddings1, allow_dangerous_deserialization=True)
            db_em2 = FAISS.load_local(faiss_index_path_em2, embeddings2, allow_dangerous_deserialization=True)

            retriever_em1 = db_em1.as_retriever(search_kwargs=search_kwargs)
            retriever_em2 = db_em2.as_retriever(search_kwargs=search_kwargs)

            retriever = EnsembleRetriever(
                retrievers=[retriever_em1, retriever_em2], weights=[0.5, 0.5]
            )


    else:

        if use_two_db:
            faiss_index_path_cn = f"./db/faiss_index_cscn{cs_cn}_cocn{co_cn}_distpo_{dist_po}_{file_type}_{em1}"
            faiss_index_path_en = f"./db/faiss_index_csen{cs_en}_coen{co_en}_distpo_{dist_po}_{file_type}_{em1}"

            db_cn = FAISS.load_local(faiss_index_path_cn, embeddings1, allow_dangerous_deserialization=True)
            db_en = FAISS.load_local(faiss_index_path_en, embeddings1, allow_dangerous_deserialization=True)
            retriever_cn = db_cn.as_retriever(search_kwargs=search_kwargs)
            retriever_en = db_en.as_retriever(search_kwargs=search_kwargs)
            retriever = EnsembleRetriever(
                retrievers=[retriever_cn, retriever_en], weights=[0.5, 0.5]
            )


        else:
            faiss_index_path = f'./db/faiss_index_cs{cs}_co{co}_distpo_{dist_po}_{file_type}_{em1}'

            db = FAISS.load_local(faiss_index_path, embeddings1, allow_dangerous_deserialization=True)
            retriever = db.as_retriever(search_kwargs=search_kwargs)

    return retriever


def main():
    # st.set_page_config(layout="wide")
    st.set_page_config(layout="centered")

    st.title("学术内容判断系统")

    prompt_str_noreason = """给定以下上下文和一个陈述，请根据提供的上下文判断陈述是否正确。
        请特别注意细节和微小的差异，这些细节可能会影响判断的正确性。
        只需判断正确还是错误，如果正确就输出"T"，如果错误就输出"F"。
        如果根据上下文无法确认是正确的，则默认错误，输出"F"。
        注意过于绝对的说法一般是错误的。
        你的最终输出应该只包含"T"、"F"中的一个，不用说明理由。
        上下文: {context}
        陈述: {input}"""
    
    
    prompt_str_reason = """给定以下上下文和一个陈述，请根据提供的上下文判断陈述是否正确，并给出理由。
        请特别注意细节和微小的差异，比如时间、地点、原因等要素，这些细节可能会影响判断结果。
        注意过于绝对的说法一般是错误的。
        上下文: {context}
        陈述: {input}"""

    # output_parser = CustomOutputParser()
    output_parser = StrOutputParser()

    # 设置模型参数
    # model_name = "/root/autodl-tmp/embedding_model/bge-m3"

    model_kwargs = {'device': 'cuda'}
    encode_kwargs = {'normalize_embeddings': True}

    # reranker_args = {'model': '/root/autodl-tmp/embedding_model/bce-reranker-base_v1', 'top_n': 6, 'device': 'cuda:0'}
    # reranker = BCERerank(**reranker_args)

    # Streamlit 用户选择参数
    use_two_em_options = [True, False]
    use_two_em_default = True
    use_two_db_options = [True, False]
    use_two_db_default = True

    cscn_options = [300, 500]
    cocn_options = [50, 100]

    csen_options = [300, 500, 700, 800]
    coen_options = [50, 100, 150, 200]

    cscn_default = 300
    cocn_default = 50

    csen_default = 500
    coen_default = 100

    cs_options = [300, 500, 800, 1000]
    co_options = [50, 100, 200]
    cs_default = 500
    co_default = 100

    k1_default = 12
    k2_default = 10
    search_type_options = ['similarity', 'mmr']  # 只包含 'similarity' 和 'mmr'
    search_type_default = 'mmr'
    lambda_mult_default = 0.5
    file_type_options = ['pdf', 'txt', 'md']
    file_type_default = 'txt'
    embedding_model_options = ['distiluse-base-multilingual-cased-v2', 'paraphrase-multilingual-MiniLM-L12-v2',
                               'bge-m3', 'bce-embedding-base_v1',
                               ]
    # embedding_model_default = embedding_model_options[0]
    em1_default = embedding_model_options[0]
    em2_default = embedding_model_options[1]

    dist_po_options = ['ed', 'cos', 'mip', 'dp']
    dist_po_default = 'cos'
    rerank_model_options = ['bge-reranker-large', 'bge-reranker-v2-m3', 'bce-reranker-base_v1']
    rerank_model_default = 'bge-reranker-large'
    llm_default = 'qwen1_5-14b-chat-q8_0'

    prompt_str_options = [prompt_str_noreason, prompt_str_reason]
    prompt_str_default = prompt_str_reason

    # 如果 session_state 中没有 cs、co、k、search_type 或 lambda_mult，则初始化它们
    if 'use_two_em' not in st.session_state:
        st.session_state.use_two_em = use_two_em_default
    if 'em1' not in st.session_state:
        st.session_state.em1 = em1_default
    if 'em2' not in st.session_state:
        st.session_state.em2 = em2_default

    if 'use_two_db' not in st.session_state:
        st.session_state.use_two_db = use_two_db_default

    if 'cscn' not in st.session_state:
        st.session_state.cscn = cscn_default
    if 'cocn' not in st.session_state:
        st.session_state.cocn = cocn_default

    if 'csen' not in st.session_state:
        st.session_state.csen = csen_default
    if 'coen' not in st.session_state:
        st.session_state.coen = coen_default

    if 'cs' not in st.session_state:
        st.session_state.cs = cs_default
    if 'co' not in st.session_state:
        st.session_state.co = co_default

    if 'k1' not in st.session_state:
        st.session_state.k1 = k1_default

    if 'k2' not in st.session_state:
        st.session_state.k2 = k2_default

    if 'search_type' not in st.session_state:
        st.session_state.search_type = search_type_default
    if 'lambda_mult' not in st.session_state:
        st.session_state.lambda_mult = lambda_mult_default
    if 'file_type' not in st.session_state:
        st.session_state.file_type = file_type_default

    if 'rerank_model' not in st.session_state:
        st.session_state.rerank_model = rerank_model_default

    if 'dist_po' not in st.session_state:
        st.session_state.dist_po = dist_po_default
    if 'rerank_model' not in st.session_state:
        st.session_state.rerank_model = rerank_model_default

    if 'prompt_str' not in st.session_state:
        st.session_state.prompt_str = prompt_str_default
    if 'llm_name' not in st.session_state:
        st.session_state.llm_name = llm_default

    # 创建选择框和输入框
    file_type = st.sidebar.selectbox('Choose embedding file type', file_type_options,
                                     index=file_type_options.index(st.session_state.file_type))

    rerank_model = st.sidebar.selectbox('Choose reranking model', rerank_model_options,
                                        index=rerank_model_options.index(st.session_state.rerank_model))

    use_two_em = st.sidebar.selectbox('Choose whether use two embedding model', use_two_em_options,
                                      index=use_two_em_options.index(st.session_state.use_two_em))

    em1 = st.sidebar.selectbox('Choose embedding model 1', embedding_model_options,
                               index=embedding_model_options.index(st.session_state.em1))

    em2 = st.sidebar.selectbox('Choose embedding model 2', embedding_model_options,
                               index=embedding_model_options.index(st.session_state.em2))

    use_two_db = st.sidebar.selectbox('Choose whether use two db', use_two_db_options,
                                      index=use_two_db_options.index(st.session_state.use_two_db))

    cscn = st.sidebar.selectbox('Choose cs_cn value', cscn_options, index=cscn_options.index(st.session_state.cscn))
    cocn = st.sidebar.selectbox('Choose co_cn value', cocn_options, index=cocn_options.index(st.session_state.cocn))

    csen = st.sidebar.selectbox('Choose cs_en value', csen_options, index=csen_options.index(st.session_state.csen))
    coen = st.sidebar.selectbox('Choose co_en value', coen_options, index=coen_options.index(st.session_state.coen))

    cs = st.sidebar.selectbox('Choose cs value', cs_options, index=cs_options.index(st.session_state.cs))
    co = st.sidebar.selectbox('Choose co value', co_options, index=co_options.index(st.session_state.co))

    k1 = st.sidebar.number_input('Choose k1 value', min_value=1, value=st.session_state.k1)
    k2 = st.sidebar.number_input('Choose k2 value', min_value=1, value=st.session_state.k2)

    search_type = st.sidebar.selectbox('Choose search type', search_type_options,
                                       index=search_type_options.index(st.session_state.search_type))
    lambda_mult = st.sidebar.number_input('Choose lambda mult value', min_value=0.0, max_value=1.0,
                                          value=st.session_state.lambda_mult)

    dist_po = st.sidebar.selectbox('Choose distance strategy', dist_po_options,
                                   index=dist_po_options.index(st.session_state.dist_po))

    prompt_str = st.sidebar.selectbox('Choose the prompt template', prompt_str_options,
                                      index=prompt_str_options.index(st.session_state.prompt_str))

    llm_name = st.sidebar.text_input('Enter the LLM name', value=llm_default)

    # 确定按钮，用于在更改参数后重新加载模型
    if st.sidebar.button('Confirm Parameters'):
        st.session_state.retriever = load_index_model(file_type, use_two_em, em1, em2, use_two_db, cscn, cocn, csen,
                                                      coen,
                                                      cs, co, k1, search_type, lambda_mult, dist_po,
                                                      model_kwargs, encode_kwargs)
        st.session_state.file_type = file_type
        st.session_state.use_two_em = use_two_em
        st.session_state.em1 = em1
        st.session_state.em2 = em2
        st.session_state.rerank_model = rerank_model

        st.session_state.use_two_db = use_two_db

        st.session_state.cscn = cscn
        st.session_state.cocn = cocn
        st.session_state.csen = csen
        st.session_state.coen = coen

        st.session_state.cs = cs
        st.session_state.co = co

        st.session_state.k1 = k1
        st.session_state.k2 = k2

        st.session_state.search_type = search_type
        st.session_state.lambda_mult = lambda_mult
        st.session_state.dist_po = dist_po
        st.session_state.prompt_str = prompt_str
        st.session_state.llm_name = llm_name

    # 如果 'retriever' 不在 session_state 中，则初始化它
    if 'retriever' not in st.session_state:
        st.session_state.retriever = load_index_model(st.session_state.file_type, st.session_state.use_two_em,
                                                      st.session_state.em1, st.session_state.em2,
                                                      st.session_state.use_two_db,
                                                      st.session_state.cscn, st.session_state.cocn,
                                                      st.session_state.csen, st.session_state.coen,
                                                      st.session_state.cs, st.session_state.co, st.session_state.k1,
                                                      st.session_state.search_type, st.session_state.lambda_mult,
                                                      dist_po, model_kwargs, encode_kwargs,
                                                      )

    rerank_model_path = embedding_model_dir + st.session_state.rerank_model
    if st.session_state.rerank_model == 'bce-reranker-base_v1':

        reranker_args = {'model': rerank_model_path, 'top_n': st.session_state.k2, 'device': 'cuda:0'}
        reranker = BCERerank(**reranker_args)
    elif 'bge' in st.session_state.rerank_model:
        temp_model = HuggingFaceCrossEncoder(model_name=rerank_model_path)
        reranker = CrossEncoderReranker(model=temp_model, top_n=st.session_state.k2)
    else:
        raise NotImplementedError("The specified reranker model is not implemented.")

    compression_retriever = ContextualCompressionRetriever(
        base_compressor=reranker, base_retriever=st.session_state.retriever
    )

    # Streamlit 用户输入
    query = st.text_input("Enter your query:",
                          value="中兴通讯提出的基于来车识别的载波点亮方案，通过准确识别来车并结合铁路通信网络业务潮汐效应特征，实现了很好的节能效果。")
    reordering = LongContextReorder()

    if st.button("确认"):
        # 执行查询并打印结果
        docs = st.session_state.retriever.invoke(query)
        # reordered_docs = reordering.transform_documents(docs)
        reranked_docs = compression_retriever.invoke(query)
        final_docs = reordering.transform_documents(reranked_docs)

        # 创建三个宽度相等的列
        left_column, middle_column, right_column = st.columns([1, 1, 1])
        # left_column, right_column = st.columns([1, 1, 1])

        # 显示原始检索文档
        left_column.markdown("<h2 style='color: red;'>原始检索文档:</h2>", unsafe_allow_html=True)
        for i, d in enumerate(docs):
            left_column.write(f"<h3 style='color: blue;'>Document {i + 1}:</h3>", unsafe_allow_html=True)
            left_column.write(d.page_content)

        # # 显示重新排序后的文档
        # middle_column.markdown("<h2 style='color: red;'>重组顺序后的文档:</h2>", unsafe_allow_html=True)
        # for i, d in enumerate(reordered_docs):
        #     middle_column.write(f"<h3 style='color: blue;'>Document {i + 1}:</h3>", unsafe_allow_html=True)
        #     middle_column.write(d.page_content)

        # 显示重新排名后的文档
        middle_column.markdown("<h2 style='color: red;'>重排及重组后的文档:</h2>", unsafe_allow_html=True)
        for i, d in enumerate(final_docs):
            middle_column.write(f"<h3 style='color: blue;'>Document {i + 1}:</h3>", unsafe_allow_html=True)
            middle_column.write(d.page_content)

        llm = Ollama(model=st.session_state.llm_name, temperature=0.0, num_ctx=8192)
        prompt = ChatPromptTemplate.from_template(st.session_state.prompt_str)
        document_chain = create_stuff_documents_chain(llm, prompt, output_parser=output_parser)
        response = document_chain.invoke({"context": final_docs, "input": query})
        right_column.markdown("<h2 style='color: red;'>LLM回答:</h2>", unsafe_allow_html=True)
        right_column.write(response)


if __name__ == "__main__":
    main()
